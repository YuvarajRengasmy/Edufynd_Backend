import { Router } from 'express';
import { getAllStaff, getSingleStaff, createStaff, updateStaff, deleteStaff, getFilteredStaff } from '../controller/staff.controller';
import { checkQuery, checkRequestBodyParams } from '../middleware/Validators';
import { basicAuthUser } from '../middleware/checkAuth';
import { checkSession } from '../utils/tokenManager';

const router: Router = Router();

router.get('/getAll',                //get all staff Details
    basicAuthUser,
    checkSession,
    getAllStaff
);

router.get('/',
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    getSingleStaff,
);


router.post('/',           // create staff
    basicAuthUser,
    checkSession,
    createStaff
);


router.put('/',                    // update Staff Details
    basicAuthUser,
    checkSession,
    // checkQuery('_id'),
    checkRequestBodyParams('_id'),
    updateStaff
);


router.delete('/',                  //delete staff
    basicAuthUser,
    checkSession,
    checkQuery('_id'),
    deleteStaff
);



router.put('/getFilterStaff',
    basicAuthUser,
    checkSession,
    getFilteredStaff,
);

export default router