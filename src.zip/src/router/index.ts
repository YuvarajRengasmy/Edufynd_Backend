import { Router } from 'express';
const router: Router = Router();


// All Module Routes
import SuperAdmin from './superAdmin.routes'
import Admin from './admin.routes'
import Student from './student.routes'
import Agent from './agent.routes'
import Login from './login.routes'
import University from './university.routes'
import Program from './program.routes'
import Applicant from './applicant.routes'
import Contact from './contact.routes'
import Client from './client.routes'
import Staff from './staff.routes'
import Blog from '../blogs/blogs.routes'
import Commission from './commission.routes'



// All Enquiry Routes
import GeneralEnquiry  from '../enquiries/routes/generalEnquiry.route';
import BusinessEnquiry  from '../enquiries/routes/businessEnquiry.route';
import StudentEnquiry from '../enquiries/routes/studentEnquiry.route'
import LoanEnquiry  from '../enquiries/routes/loanEnquiry.route';
import Accommodation from '../enquiries/routes/accommodation.route'
import Forex from '../enquiries/routes/forex.route'
import Flight from '../enquiries/routes/flightTicket.route'


// Invoice Routes
import SenderInvoice from '../finance/routes/senderInvoice.route';
import ReceiverInvoice from '../finance/routes/receiverInvoice.route'


// Marketing
import Marketing from '../marketing/marketing.routes'

// Notification
import Notification from '../notification/notification.routes'

// Promotion
import Promotion from '../promotion/promotion.routes'

// Meeting
import Meeting from '../meeting/meeting.routes'

// Training
import Training from '../training/training.routes'

// Events
import Event from '../events/event.routes'



//Global Setting Routes
import Status from '../setting/globalSetting/router/status.routes'
import Country from '../setting/globalSetting/router/country.routes'
import InTake from '../setting/globalSetting/router/intake.routes'
import Email from '../setting/globalSetting/router/email.routes'
import Currency from '../setting/globalSetting/router/currency.routes'
import Year from '../setting/globalSetting/router/year.routes'



//Drop Down Setting Routes
import CourseType from '../setting/moduleSetting/router/courseType.route'
import PopularCategory from '../setting/moduleSetting/router/popularCourse.route'
import CommissionPaid from '../setting/moduleSetting/router/commissionPaid.route'
import CountryList from '../setting/moduleSetting/router/country.route'
import InstitutionType from '../setting/moduleSetting/router/institutionType.route'
import OfferTAT from '../setting/moduleSetting/router/offerTAT.route'
import PaymentMethod from '../setting/moduleSetting/router/paymentMethod.route'
import Tax from '../setting/moduleSetting/router/tax.route'
import TypeOfClient from '../setting/moduleSetting/router/typeOfClient.route'





// All Module API
router.use('/superadmin', SuperAdmin)
router.use('/admin', Admin)
router.use('/student', Student)
router.use('/agent', Agent)
router.use('/login', Login)
router.use('/university', University)
router.use('/program', Program)
router.use('/applicant', Applicant)
router.use('/contact', Contact)
router.use('/client', Client)
router.use('/staff', Staff)
router.use('/blog', Blog)
router.use('/commission', Commission)


//All Enquiry API
router.use('/generalEnquiry', GeneralEnquiry)
router.use('/businessEnquiry', BusinessEnquiry)
router.use('/studentEnquiry', StudentEnquiry)
router.use('/loan', LoanEnquiry)
router.use('/accommodation', Accommodation)
router.use('/forex', Forex)
router.use('/flight', Flight)

// Invoice API
router.use('/senderInvoice', SenderInvoice)
router.use('/receiverInvoice', ReceiverInvoice)

// Marketing
router.use('/marketing', Marketing)


// Notification
router.use('/notification', Notification)

// Meeting
router.use('/meeting', Meeting)

// Promotion
router.use('/promotion', Promotion)

// Training
router.use('/training', Training)

// Events
router.use('/event', Event)




//Global Setting API
router.use('/status', Status )
router.use('/country', Country)
router.use('/intake', InTake)
router.use('/email', Email)
router.use('/currency', Currency)
router.use('/year', Year)


//Drop Down - Setting API
router.use('/course', CourseType )
router.use('/popularCourse', PopularCategory )
router.use('/commissionPaid', CommissionPaid)
router.use('/institutionType', InstitutionType)
router.use('/countryList', CountryList)
router.use('/offerTAT', OfferTAT)
router.use('/paymentMethod', PaymentMethod)
router.use('/tax', Tax)
router.use('/typeOfClient', TypeOfClient)






export default router